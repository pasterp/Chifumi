package Chifumi;

/**
 * Created by pphelipo on 09/05/2016.
 */
public abstract class DefaultMotif implements Motif{
    protected String image="img/lezard.png";

    public String getImage(){
        return image;
    }

    @Override
    public boolean perd(Pierre m) {
        return false;
    }

    @Override
    public boolean perd(Spock m) {
        return false;
    }

    @Override
    public boolean perd(Feuille m) {
        return false;
    }

    @Override
    public boolean perd(Ciseaux m) {
        return false;
    }

    @Override
    public boolean perd(Lezard m) {
        return false;
    }
}
