package Chifumi;

/**
 * Created by mahatehotia on 07/03/16.
 */
public class Chifumi {
    public static int compareMotifs(Motif m1, Motif m2){
        if ( m1.gagne(m2) && !m2.gagne(m1))
            return 1;
        else if (m2.gagne(m1) && !m1.gagne(m2) )
            return 2;
        else
            return 0;
    }
}
