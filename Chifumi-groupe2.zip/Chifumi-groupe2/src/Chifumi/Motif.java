package Chifumi;

/**
 * Created by mahatehotia on 07/03/16.
 */
public interface Motif {

    public boolean gagne(Motif m);


    public boolean perd(Pierre m);
    public boolean perd(Feuille m);
    public boolean perd(Spock m);
    public boolean perd(Ciseaux m);
    public boolean perd(Lezard m);
    public String getImage();

}
