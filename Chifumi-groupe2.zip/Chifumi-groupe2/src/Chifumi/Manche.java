package Chifumi;

import controller.MancheController;

import javax.swing.*;

/**
 * Created by pphelipo on 02/05/2016.
 */
public class Manche {

    public Joueur joueur1;
    public Joueur joueur2;
    private int nbDuelTotal;

    public Manche(Joueur j1,Joueur j2) {
        joueur1=j1;
        joueur2=j2;
        resetManche();
    }

    public void resetManche(){
        joueur1.resetDuelsGagnes();
        joueur1.distribuerCartes();
        joueur2.resetDuelsGagnes();
        joueur2.distribuerCartes();

        nbDuelTotal = 0;
    }

    public boolean isFinie() {
        if (joueur1.getDuelsGagnes() == 3 || joueur2.getDuelsGagnes() == 3) {
            if(joueur2.getDuelsGagnes() > joueur1.getDuelsGagnes())
                joueur2.addManchesGagnees();
            else
                joueur1.addManchesGagnees();
            resetManche();
            return true;
        } else if (nbDuelTotal == 15) {
            resetManche();
            return true;
        } else {
            return false;

        }
    }

    public void jouerUnDuel(Motif m1, Motif m2) {
        nbDuelTotal++;
        int result = Chifumi.compareMotifs(m1, m2);
        switch (result){
            case 1:
                joueur1.gagne();
                break;
            case 2:
                joueur2.gagne();
                break;
            default:
                //Egalité
        }
    }
}
