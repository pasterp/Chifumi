package Chifumi;

import java.util.List;

/**
 * Created by pphelipo on 02/05/2016.
 */
public class ChoixMotifJoueur implements ChoixMotif {
    @Override
    public int choisirCartes(List<Motif> main) {
        return 0;
    }
}
