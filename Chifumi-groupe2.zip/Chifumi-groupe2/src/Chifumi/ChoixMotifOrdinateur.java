package Chifumi;

import java.util.List;
import java.util.Random;

/**
 * Created by pphelipo on 02/05/2016.
 */
public class ChoixMotifOrdinateur implements ChoixMotif {
    @Override
    public int choisirCartes(List<Motif> main) {
        return new Random().nextInt(main.size());
    }
}
