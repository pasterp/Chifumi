package Chifumi;

/**
 * Created by mahatehotia on 14/03/16.
 */
public class Feuille extends DefaultMotif {
    public Feuille(){
        image = "img/feuille.png";
    }

    @Override
    public boolean gagne(Motif m) {
        return m.perd(this);
    }

    @Override
    public boolean perd(Ciseaux m) {
        return true;
    }

    @Override
    public boolean perd(Lezard m) {
        return true;
    }
}
