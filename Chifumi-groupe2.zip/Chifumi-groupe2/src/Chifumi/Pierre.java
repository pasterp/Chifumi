package Chifumi;

/**
 * Created by mahatehotia on 07/03/16.
 */
public class Pierre extends DefaultMotif {
    public Pierre(){
        super();
        image = "img/pierre.png";
    }

    @Override
    public boolean gagne(Motif m) {
        return m.perd(this);
    }

    @Override
    public boolean perd(Feuille m) {
        return true;
    }

    @Override
    public boolean perd(Spock m) {
        return true;
    }

}
