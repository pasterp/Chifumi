package Chifumi;

import java.util.List;

/**
 * Created by pphelipo on 02/05/2016.
 */
public abstract interface ChoixMotif {

    public abstract int choisirCartes(List<Motif> main);
}
