package Chifumi;

/**
 * Created by mahatehotia on 07/03/16.
 */
public class Ciseaux extends DefaultMotif {
    public Ciseaux (){
        super();
        image = "img/ciseau.png";
    }

    @Override
    public boolean gagne(Motif m) {
        return m.perd(this);
    }

    @Override
    public boolean perd(Pierre m) {
        return true;
    }

    @Override
    public boolean perd(Spock m) {
        return true;
    }

}
