package Chifumi;

/**
 * Created by mahatehotia on 14/03/16.
 */
public class Lezard extends DefaultMotif {
    public Lezard(){
        super();
        image = "img/TrueLezard.png";
    }

    @Override
    public boolean gagne(Motif m) {
        return m.perd(this);
    }

    @Override
    public boolean perd(Pierre m) {
        return true;
    }

    @Override
    public boolean perd(Ciseaux m) {
        return true;
    }

}
