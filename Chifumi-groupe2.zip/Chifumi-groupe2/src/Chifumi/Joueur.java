package Chifumi;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by pphelipo on 25/04/2016.
 */
public class Joueur {
    private ArrayList<Motif> main;
    private int duelsGagnes;
    private int manchesGagnees;
    private ChoixMotif choixMotif;

    public int getManchesGagnees() {
        return manchesGagnees;
    }

    public void addManchesGagnees() {
        this.manchesGagnees++;
    }

    public Joueur(ChoixMotif choix){
        main = new ArrayList<>();
        choixMotif = choix;
        duelsGagnes=0;
        manchesGagnees=0;
    }

    public ArrayList<Motif> getMain() {
        return main;
    }

    public void distribuerCartes() {
        main.clear();
        for (int i = 0; i < 3; i++){
            main.add(new Ciseaux());
            main.add(new Feuille());
            main.add(new Lezard());
            main.add(new Spock());
            main.add(new Pierre());
        }
    }

    public void resetDuelsGagnes() {
        this.duelsGagnes = 0;
    }

    public int getDuelsGagnes() {
        return duelsGagnes;
    }

    public Motif jouerCarte(){
        return main.remove(choixMotif.choisirCartes(main));
    }

    public void gagne(){
        duelsGagnes++;
    }

    @Override
    public String toString() {
        String d =  "Joueur:";
        for (Motif m : main)
            d+=m+"\n";

        return d;
    }
}
