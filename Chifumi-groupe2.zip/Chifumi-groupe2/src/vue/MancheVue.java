package vue;

import Chifumi.Manche;
import Chifumi.Motif;
import controller.MancheController;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pphelipo on 09/05/2016.
 */
public class MancheVue extends JFrame{
    Manche mManche;

    JPanel mPanelJ1,mPanelPlateau, mPanelGrille;
    JLabel mLabelPlateauJ1, mLabelPlateauJ2;
    JLabel mLabelJ1Score;
    JLabel mLabelJ2Score;
    JButton carteJ1;
    JMenu option;
    JMenuItem newPartie, bestScore;
    JMenuBar menuBar;

    MancheController mancheController;

    public JLabel getmLabelPlateauJ1() {
        return mLabelPlateauJ1;
    }

    public JLabel getmLabelPlateauJ2() {
        return mLabelPlateauJ2;
    }

    public JLabel getmLabelJ1Score() {
        return mLabelJ1Score;
    }

    public JLabel getmLabelJ2Score() {
        return mLabelJ2Score;
    }

    public List<JButton> getCartesJ1() {
        return cartesJ1;
    }

    List<JButton> cartesJ1;


    public MancheVue(Manche manche){
        super();

        mManche = manche;

        setSize(800, 600);
        setVisible(true);


        setTitle("BEST GAME EVER");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        add(new JLabel("CHATONezreztztzrt"));

        menuBar = new JMenuBar();
        option = new JMenu("Options");
        newPartie = new JMenuItem("Nouvelle Partie");
        option.add(newPartie);
        bestScore = new JMenuItem("Meilleur Score");
        option.add(bestScore);
        menuBar.add(option);
        setJMenuBar(menuBar);


        initialiserWidgets();
        placerWidgets();
        updateFenetre();
        pack();
    }

    public void initialiserWidgets(){
        mPanelJ1 = new JPanel();
        cartesJ1 = new ArrayList<>();
        mLabelPlateauJ1 = new JLabel("test");
        mLabelPlateauJ1.setPreferredSize(new Dimension(200,200));
        mLabelPlateauJ1.setOpaque(true);
        mLabelPlateauJ1.setBackground(new Color(0,0,0));

        mLabelPlateauJ2 = new JLabel();
        mLabelPlateauJ2.setPreferredSize(new Dimension(200,200));
        mLabelPlateauJ2.setOpaque(true);
        mLabelPlateauJ2.setBackground(new Color(0255,0255,0255));

        mPanelPlateau = new JPanel();

        mLabelJ1Score = new JLabel("Score J1 : 0");
        mLabelJ2Score = new JLabel("Score J2 : 0");

        carteJ1 = new JButton();

        mPanelGrille = new JPanel();
    }

    public void updateFenetre(){
        mPanelJ1.removeAll();
        cartesJ1.clear();

        repaint();

        mLabelJ1Score.setText("Joueur 1 : " + mManche.joueur1.getDuelsGagnes());
        mLabelJ2Score.setText("Joueur 2 : " + mManche.joueur2.getDuelsGagnes());


        for (Motif m :mManche.joueur1.getMain()){
            JButton gentilBouton = new JButton(new ImageIcon(new ImageIcon(m.getImage()).getImage().getScaledInstance(50,50,Image.SCALE_DEFAULT)));
            cartesJ1.add(gentilBouton);
            mPanelJ1.add(gentilBouton);
        }
        addListeners();

       pack();//de bières
    }



    public void placerWidgets(){

        //mPanelJ1.setLayout();
        mPanelPlateau.add(mLabelPlateauJ2);
        mPanelPlateau.add(mLabelPlateauJ1);
        mPanelGrille.setLayout(new BorderLayout());

        JPanel scores = new JPanel();
        scores.add(mLabelJ2Score);
        scores.add(mLabelJ1Score);

        mPanelGrille.add(scores, BorderLayout.NORTH);

        mPanelGrille.add(mPanelJ1, BorderLayout.SOUTH);
        mPanelGrille.add(mPanelPlateau,BorderLayout.CENTER);

        add(mPanelGrille);

    }

    public void addListeners(MancheController mancheController) {
        this.mancheController = mancheController;
        addListeners();
    }

    public void addListeners() {
        for (JButton b : cartesJ1)
            b.addActionListener(mancheController);
    }

    public void afficherFinManche(String s){
        JOptionPane.showMessageDialog(null, s);
    }
}
