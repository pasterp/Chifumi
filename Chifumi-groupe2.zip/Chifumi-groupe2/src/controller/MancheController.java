package controller;

import Chifumi.*;
import vue.MancheVue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Created by pphelipo on 09/05/2016.
 */
public class MancheController implements ActionListener {

    private MancheVue vue;
    private Manche manche;

    public MancheController(MancheVue mv, Manche manche1){
        vue=mv;
        manche = manche1;
        vue.addListeners(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        List<JButton> l=vue.getCartesJ1();
        for(int i=0; i<l.size(); i++){
            if(e.getSource()==l.get(i)){
                Motif m1 = manche.joueur1.getMain().remove(i);

                vue.getmLabelPlateauJ1().setIcon(new ImageIcon(new ImageIcon(m1.getImage()).getImage().getScaledInstance(200,200, Image.SCALE_DEFAULT)));
                Motif m2 = manche.joueur2.jouerCarte();
                vue.getmLabelPlateauJ2().setIcon(new ImageIcon(new ImageIcon(m2.getImage()).getImage().getScaledInstance(200,200, Image.SCALE_DEFAULT)));

                manche.jouerUnDuel(m1, m2);
                vue.updateFenetre();

                if (manche.isFinie()){
                    String etat = "Manches gagnés : \nJoueur 1 : "+manche.joueur1.getManchesGagnees()+"\nJoueur 2 : "+manche.joueur2.getManchesGagnees();

                    if(manche.joueur1.getManchesGagnees() == 3 || manche.joueur2.getManchesGagnees() == 3) {
                        if (manche.joueur1.getManchesGagnees() == 3)
                            etat = "Fin de partie !\nJoueur 1 Gagnant !!!";
                        else
                            etat = "Fin de partie !\nJoueur 2 Gagnant !!!";

                        vue.afficherFinManche(etat);
                        vue.setVisible(false);
                        System.exit(0);
                    }else
                        vue.afficherFinManche(etat);

                    vue.updateFenetre();
                }


            }
        }

    }



    public static void main(String[] args) {
        Manche manche;
        Joueur j1,j2;
        j1 = new Joueur(new ChoixMotifJoueur());
        j2 = new Joueur(new ChoixMotifOrdinateur());
        manche = new Manche(j1,j2);
        MancheVue test = new MancheVue(manche);
        MancheController mancheController = new MancheController(test, manche);
    }
}
