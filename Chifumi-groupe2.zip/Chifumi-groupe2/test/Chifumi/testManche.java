package Chifumi;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Created by pphelipo on 02/05/2016.
 */
public class testManche {
    private ChoixMotif testChoixMotif = new ChoixMotif() {
        @Override
        public int choisirCartes(List<Motif> main) {
            return 0;
        }
    };

    @Test
    public void etatManche(){
        Joueur j1 = new Joueur(testChoixMotif);
        Joueur j2 = new Joueur(testChoixMotif);
        Manche manche = new Manche(j1,j2);
        Assert.assertFalse(manche.isFinie());
        for (int i = 0; i <15 ; i++) {
            manche.jouerUnDuel(new Pierre(), new Pierre()); //Rolling stones <3
        }
        Assert.assertTrue(manche.isFinie());


    }

    @Test
    public void testDuel(){
        Joueur j1 = new Joueur(testChoixMotif);
        Joueur j2 = new Joueur(testChoixMotif);
        Manche manche = new Manche(j1,j2);
        manche.jouerUnDuel(new Ciseaux(),new Pierre());

        Assert.assertEquals(j2.getDuelsGagnes(), 1);

        manche.jouerUnDuel(new Pierre(), new Ciseaux());
        Assert.assertEquals(j1.getDuelsGagnes(), 1);

        manche.jouerUnDuel(new Pierre(), new Pierre());
        Assert.assertEquals(j1.getDuelsGagnes(), 1);
        Assert.assertEquals(j2.getDuelsGagnes(), 1);
    }



    @Test
    public void faireGagner(){
        Joueur j1 = new Joueur(testChoixMotif);
        Joueur j2 = new Joueur(testChoixMotif);
        Manche manche = new Manche(j1,j2);


        //gain joueur 1
        for (int i = 0; i < 3 ; i++) {
            j1.getMain().clear();
            j2.getMain().clear();
            j1.getMain().add(new Pierre());
            j2.getMain().add(new Ciseaux());
            manche.jouerUnDuel(j1.jouerCarte(),j2.jouerCarte());
        }
        Assert.assertTrue(manche.isFinie());

        manche = new Manche(j1,j2);
        //Gain joueur 2
        for (int i = 0; i < 3 ; i++) {
            j1.getMain().clear();
            j2.getMain().clear();
            j2.getMain().add(new Pierre());
            j1.getMain().add(new Ciseaux());
            manche.jouerUnDuel(j1.jouerCarte(),j2.jouerCarte());
        }
        Assert.assertTrue(manche.isFinie());


    }
}
