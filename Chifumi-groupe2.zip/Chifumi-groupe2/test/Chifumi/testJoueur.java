package Chifumi;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Created by pphelipo on 25/04/2016.
 */
public class testJoueur {
    ChoixMotif testChoixMotif = new ChoixMotif() {
        @Override
        public int choisirCartes(List<Motif> main) {
            return 0;
        }
    };

    @Test
    public void verifMain(){
        Joueur joueur;
        joueur = new Joueur(testChoixMotif);
        List<Motif> motifList = joueur.getMain();

        Assert.assertEquals(0, motifList.size());

        joueur.distribuerCartes();

        Assert.assertEquals(15, motifList.size());

        int pierreCmpt = 0, lezardCmpt = 0, ciseauxCmpt = 0, spockCmpt = 0, feuilleCmpt = 0;

        for (Motif m : motifList){
            if (m instanceof Pierre)
                pierreCmpt++;
            if(m instanceof Ciseaux)
                ciseauxCmpt++;
            if(m instanceof Lezard)
                lezardCmpt++;
            if(m instanceof Feuille)
                feuilleCmpt++;
            if(m instanceof Spock)
                spockCmpt++;
        }

        Assert.assertEquals(3, pierreCmpt);
        Assert.assertEquals(3, ciseauxCmpt);
        Assert.assertEquals(3, lezardCmpt);
        Assert.assertEquals(3, feuilleCmpt);
        Assert.assertEquals(3, spockCmpt);

    }

    @Test
    public void duelGagner(){
        Joueur joueur1 = new Joueur(testChoixMotif);
        Assert.assertEquals(0,joueur1.getDuelsGagnes());

        joueur1.gagne();

        Assert.assertEquals(1,joueur1.getDuelsGagnes());
    }

    @Test
    public void jouerUneCarteTest(){
        Joueur joueur = new Joueur(testChoixMotif);
        joueur.distribuerCartes();
        Motif m = joueur.getMain().get(0);

        Assert.assertEquals(m, joueur.jouerCarte());

        Assert.assertNotEquals(joueur.getMain().get(0), m);
    }
}
