package Chifumi;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by mahatehotia on v14/03/16.
 */
public class testFeuille {

    @Test
    public void testFeuille(){
        Feuille feuille = new Feuille();
        Pierre pierre = new Pierre();
        Spock spock = new Spock();
        Ciseaux ciseaux = new Ciseaux();

        Assert.assertFalse(feuille.gagne(ciseaux));
        Assert.assertTrue(feuille.gagne(pierre));
        Assert.assertTrue(feuille.gagne(spock));
    }
}
