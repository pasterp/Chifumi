package Chifumi;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by mahatehotia on 07/03/16.
 */


public class testChifumi {
    @Test
    public void testCompareMotif() {
        Pierre pierre1 = new Pierre();
        Pierre pierre2 = new Pierre();
        Feuille feuille = new Feuille();
        Assert.assertEquals(1, Chifumi.compareMotifs(feuille,pierre1));
        Assert.assertEquals(0, Chifumi.compareMotifs(pierre1,pierre2));
        Assert.assertEquals(2, Chifumi.compareMotifs(pierre1,feuille));
    }

}
