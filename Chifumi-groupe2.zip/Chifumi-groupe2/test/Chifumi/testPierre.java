package Chifumi;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by mahatehotia on 14/03/16.
 */
public class testPierre {
    @Test
    public void testGagne(){
        Pierre pierre = new Pierre();
        Lezard lezard = new Lezard();
        Ciseaux ciseaux = new Ciseaux();
        Feuille feuille = new Feuille();

        Assert.assertFalse(pierre.gagne(feuille));
        Assert.assertTrue(pierre.gagne(lezard));
        Assert.assertTrue(pierre.gagne(ciseaux));
    }
}
