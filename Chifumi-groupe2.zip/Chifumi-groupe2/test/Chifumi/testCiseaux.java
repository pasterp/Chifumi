package Chifumi;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by mahatehotia on 14/03/16.
 */
public class testCiseaux {
    @Test
    public void testGagne(){
        Feuille feuille = new Feuille();
        Pierre pierre = new Pierre();
        Ciseaux ciseaux = new Ciseaux();
        Lezard lezard = new Lezard();

        Assert.assertFalse(ciseaux.gagne(pierre));
        Assert.assertTrue(ciseaux.gagne(feuille));
        Assert.assertTrue(ciseaux.gagne(lezard));
    }

}