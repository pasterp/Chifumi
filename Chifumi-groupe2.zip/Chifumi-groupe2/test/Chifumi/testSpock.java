package Chifumi;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by mahatehotia on 14/03/16.
 */
public class testSpock {
    @Test
    public void testGagne(){
        Spock spock = new Spock();
        Pierre pierre = new Pierre();
        Ciseaux ciseaux = new Ciseaux();
        Lezard lezard = new Lezard();

        Assert.assertFalse(spock.gagne(lezard));
        Assert.assertTrue(spock.gagne(pierre));
        Assert.assertTrue(spock.gagne(ciseaux));
    }


}