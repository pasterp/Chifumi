package Chifumi;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by mahatehotia on 14/03/16.
 */
public class testLezard {
@Test
public void testGagne(){
    Spock spock = new Spock();
    Lezard lezard = new Lezard();
    Ciseaux ciseaux = new Ciseaux();
    Feuille feuille = new Feuille();

    Assert.assertFalse(lezard.gagne(ciseaux));
    Assert.assertTrue(lezard.gagne(feuille));
    Assert.assertTrue(lezard.gagne(spock));
}
}